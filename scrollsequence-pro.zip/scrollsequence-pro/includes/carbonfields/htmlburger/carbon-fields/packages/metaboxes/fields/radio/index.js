/**
 * The internal dependencies.
 */
import './style.scss';
