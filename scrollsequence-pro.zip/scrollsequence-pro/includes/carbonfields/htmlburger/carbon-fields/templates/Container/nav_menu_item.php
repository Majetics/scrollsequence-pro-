<div class="description description-wide" data-id="<?php echo $this->get_id(); ?>">
	<fieldset class="container-<?php echo $this->get_id(); ?>" data-json="<?php echo urlencode( json_encode( $this->to_json( false ) ) ); ?>"></fieldset>
</div>
